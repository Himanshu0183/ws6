package com.example.bmicalculator;

import javafx.beans.property.SimpleStringProperty;

public class Data {
    private final SimpleStringProperty bmi;
    private final SimpleStringProperty weightStatus;

    public Data(String bmi, String weightStatus) {
        this.bmi =  new SimpleStringProperty(bmi);
        this.weightStatus = new SimpleStringProperty(weightStatus);
    }

    public String getBmi() {
        return bmi.get();
    }

    public SimpleStringProperty bmiProperty() {
        return bmi;
    }

    public void setBmi(String bmi) {
        this.bmi.set(bmi);
    }

    public String getWeightStatus() {
        return weightStatus.get();
    }

    public SimpleStringProperty weightStatusProperty() {
        return weightStatus;
    }

    public void setWeightStatus(String weightStatus) {
        this.weightStatus.set(weightStatus);
    }
}
